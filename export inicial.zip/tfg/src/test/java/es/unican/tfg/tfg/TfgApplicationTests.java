package es.unican.tfg.tfg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfgApplicationTests {

	@Test
	void contextLoads() {
	}

}
